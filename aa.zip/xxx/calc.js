var shell = WScript.CreateObject("WScript.Shell");
shell.Run("calc.exe");